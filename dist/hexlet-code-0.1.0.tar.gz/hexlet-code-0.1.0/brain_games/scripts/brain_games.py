def greet(who):
    print(who)

def main():
    greet('Welcome to the Brain Games!')

if __name__ == '__main__':
    main()