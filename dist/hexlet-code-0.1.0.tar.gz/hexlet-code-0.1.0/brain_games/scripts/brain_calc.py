#!/usr/bin/env python
from brain_games.games.second import second_game

def main():
    second_game()

if __name__ == '__main__':
    main()