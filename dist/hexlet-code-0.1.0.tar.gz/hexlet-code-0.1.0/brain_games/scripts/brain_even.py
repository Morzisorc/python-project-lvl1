#!/usr/bin/env python
from brain_games.first import first_game

def main():
    first_game()

if __name__ == '__main__':
    main()