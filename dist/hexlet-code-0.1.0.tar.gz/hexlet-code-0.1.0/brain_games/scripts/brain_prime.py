# start fifth game

from brain_games import common


def main():
    common.start_game(5)


if __name__ == '__main__':
    main()
