# first brain game
from random import randint
import prompt


def first_game():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    print('Answer "yes" if the number is even, otherwise answer "no".')
    count = 0
    while count < 3:
        num = randint(1, 100)
        print(f'Question: {num}')
        answer = prompt.string('Your answer: ')
        if answer == is_even(num):
            count += 1
            print('Correct!')
            if count == 3:
                print(f'Congratulations, {name}!')
        else:
            return print(f"'{answer}' is wrong answer ;(. Correct answer was '{is_even(num)}'.\nLet's try again, {name}!'")
        

def is_even(num):
    return 'yes' if num % 2 == 0 else 'no'
