#!/usr/bin/env python
from brain_games import common

def main():
    common.start_game(1)

if __name__ == '__main__':
    main()