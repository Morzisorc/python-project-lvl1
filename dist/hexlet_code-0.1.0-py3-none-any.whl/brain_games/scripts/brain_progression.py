# start forth game

from brain_games import common


def main():
    common.start_game(4)


if __name__ == '__main__':
    main()
